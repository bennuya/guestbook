const ejs = require('ejs');

/* const booksController = require('../controllers/books_controller');
const usersController = require('../controllers/users_controller');
const jwt = require('jsonwebtoken');

module.exports = (app) => {
    app.get('./api', (req, res) => res.status(200).send({
        message: 'Welcome'
    }));


    //authentication with jwt
    app.use('/api/books/login', usersController.login);


   function ensureToken(req, res, next){
        const bearerHeader = req.headers["authorization"];

        if(typeof bearerHeader !== 'undefined'){
            const bearer = bearerHeader.split(" ");
            const bearerToken = bearer[1];

            jwt.verify(bearerToken, 'authkey', (err, decoded) => {
                if(err) {
                    return res.sendStatus(403);
                }
                req.tokeninfo = decoded;
            });

            req.token = bearerToken;

            return next();
        }else{
            console.log('Authorization failed');
            return res.sendStatus(403);
        }
    }


    app.get('/api/books', ensureToken, booksController.list);
    app.get('/api/users', usersController.list);


    app.get('/api/books', booksController.list);
    app.get('/api/users', usersController.list);
} */

module.exports = {
    
    getBooksPage: (req, res) => {
        let query = "SELECT * FROM `books`"; // query database to get all the players

        // execute query
        db.query(query, (err, result) => {
            if (err) {
                res.redirect('/');
            }
            res.render('books.ejs', {
                books: result
            });
        });
    },

};