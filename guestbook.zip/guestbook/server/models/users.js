/* module.exports = (sequelize, DataTypes) => {
    var Users = sequelize.define('Users', {
        username: {
            type: DataTypes.VARCHAR,
            allowNull: false,
        },

        password: {
            type: DataTypes.VARCHAR,
            allowNull: false,
        },

        email: {
            type: DataTypes.VARCHAR,
            allowNull: false,
        },
    });

    return Users;
}; */