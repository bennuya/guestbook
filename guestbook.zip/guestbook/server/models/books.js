/* module.exports = (sequelize, DataTypes) => {
    var Books = sequelize.define('Books', {
        title: {
            type: DataTypes.VARCHAR,
            allowNull: false,
        },

        year: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },

        author: {
            type: DataTypes.VARCHAR,
            allowNull: false,
        }
    });


    return Books;
}; */