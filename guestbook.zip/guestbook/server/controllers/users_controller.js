/* const jwt = require('jsonwebtoken');
const Users = require('../models/users').Users;

module.exports = {

    // creating a new user
    create(req, res) {
        return Users
            .create({
                username: req.body.username,
                password: req.body.password,
                lastname: req.body.lastname,
                firstname: req.body.firstname,
                age: req.body.age,
                gender: req.body.gender
            })

            .then(user => res.status(201).send({
                message: 'post was successful'
            }))
            .catch(err => res.status(400).send(err));
    },

    // listing all the users
    list(req, res){
        return Users
            .all()
            .then(users => res.status(200).send(users))
            .catch(err => res.status(400).send(err));
    },

    login(req, res){
        return Users
            .findOne(
                {
                    where: {
                        username: req.headers.username,
                        password: req.headers.password
                    }
                }
            )

            .then(user => {
                if (!user) {
                    return res.status(404).send({
                        message: 'User Not Found',
                    });
                }

                var token = jwt.sign(JSON.parse(JSON.stringify(user)), 'authkey');
                res.json( { user, token } );
            })
            .catch(err => {
                console.log(err);
                return res.status(400).send({
                message: 'authentication failed'
            })})

    }


};
 */




/* exports.signup = function (req, res) {

    if (req.method == "POST") {
        const user = {
            username = req.body.username,
            password = req.body.password,
            email = req.body.email,
        }
    
    
        db.sql("INSERT INTO users(username, password, email) VALUES ?", user, (err, res) => {
            if (err) throw err;
        });
    
    
        var query = db.query(sql, function (err, result) {
    
            message = "Succesfully! Your account has been created.";
            res.render('signup.ejs', {
                message: message
            });
        });
    } else {
        res.render('signup');
    }
    


}; */







/* exports.signup = function (req, res) {
    message = '';
    if (req.method == "POST") {
        var post = req.body;
        var name = post.username;
        var pass = post.password;
        var em = post.email;

        var sql = "INSERT INTO `users`(`username`,`password`,`email`) VALUES ('" + name + "','" + pass + "','" + em + "')";

        var query = db.query(sql, function (err, result) {

            message = "Succesfully! Your account has been created.";
            res.render('signup.ejs', {
                message: message
            });
        });

    } else {
        res.render('signup');
    }
}; */

/* exports.signup = function (req, res) {
    var users = {
        "username": req.body.username,
        "password": req.body.password,
        "email": req.body.email
    }
    connection.query('INSERT INTO users SET ?', users, function (error, results, fields) {
        if (error) {
            console.log("error ocurred", error);
            res.send({
                "code": 400,
                "failed": "error ocurred"
            })
        } else {
            console.log('The solution is: ', results);
            res.send({
                "code": 200,
                "success": "user registered sucessfully"
            });
        }
    });
}
 */



exports.signup = function (req, res) {
    message = '';
    if (req.method == "POST") {
        const user = {
            username: req.body.username,
            password: req.body.password,
            email: req.body.email
        }


        db.sql("INSERT INTO users(username, password, email) VALUES ?", user, (err, res) => {
            if (err) throw err;
        });


        var query = db.query(sql, function (err, result) {

            message = "Succesfully! Your account has been created.";
            res.render('login.ejs', {
                message: message
            });
        });
    } else {
        res.render('signup');
    }
}





/* exports.getUsers = function (req, res) {
    let query = "SELECT * FROM `users`"; // query database to get all the players

    // execute query
    db.query(query, (err, result) => {
        if (err) {
            res.redirect('/');
        }
        res.render('users.ejs', {
            users: result
        });
    });
} */




/* exports.login = function(req, res){
   var message = '';
   var sess = req.session; 

   if(req.method == "POST"){
      var post  = req.body;
      var username= post.username;
      var password= post.password;
     
      var sql="SELECT id, username, email FROM `users` WHERE `username`='"+username+"' and password = '"+password+"'";                           
      db.query(sql, function(err, results){      
         if(results.length){
            req.session.userId = results[0].id;
            req.session.user = results[0];
            console.log(results[0].id);
            res.redirect('/books');
         }
         else{
            message = 'Wrong Credentials.';
            res.render('login.ejs',{ message: message });
         }
                 
      });
   } else {
      res.render('login.ejs',{ message: message });
   }
           
}; */