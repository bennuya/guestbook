/* const Book = require('../models/books').Books;
const fs = require('fs');

module.exports = {

    // creating a new book
    create(req, res){
        return Book
            .create({
                title: req.body.title,
                year: req.body.year,
                author: req.body.author
            })

            .then(books => res.status(201).send({
                message: 'post was successful'
            }))
            .catch(err => res.status(400).send(err));
    },

    // listing all the books
    list(req, res){
        return Book
            .all()
            .then(books => res.status(200).send(books))
            .catch(err => res.status(400).send(err));
    },

    // retrieve a book by is
    retrieve(req, res){
        return Book
            .findById(req.params.bookId)
            .then(book => {
                if(!book){
                    return res.status(404).send({
                        message: 'Book Not Found'
                    })
                }

                return res.status(200).send(books);
            })

            .catch(err => res.status(400).send(err));
    },

    // updating a book
    update(req, res) {
        return Book
            .findById(req.params.bookId)

            .then(book => {
                if (!book) {
                    return res.status(404).send({
                        message: 'Book Not Found',
                    });
                }
                return book
                    .update({
                        title: req.body.title || book.title,
                        year: req.body.year || book.year,
                        author: req.body.author || book.author
                    })
                    .then(() => res.status(200).send(book))
                    .catch((error) => res.status(400).send(error));
            })
            .catch((error) => res.status(400).send(error));
    },

    // deleting one single book by id
    destroy(req, res){
        return Book
            .findById(req.params.bookId)
            .then(book => {
                if(!book) {
                    return res.status(404).send({
                        message: 'Book Not Found'
                    });
                }

                return book
                    .destroy()
                    .then(() => res.status(200).send({
                        message: 'Book deleted successfully!'
                    }))
                    .catch((err) => res.status(400).send(err));
            })

            .catch(err => res.status(400).send(err));
    },



}; */