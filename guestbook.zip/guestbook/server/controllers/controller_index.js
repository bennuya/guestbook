/* const books = require('./books');
const users = require('./users');

module.exports = {
    books,
    users
}; */