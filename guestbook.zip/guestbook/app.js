/* imports */
const booksController = require('./server/controllers/books_controller');

const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const mysql = require('mysql');
const app = express();
const path = require('path');
const user = require('./server/controllers/users_controller');

const ejs = require('ejs');	
const session = require('express-session');
app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}))


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

const port = 8080;

const {
    getHomePage,
    getBooksPage
 } = require('./server/routes/routes');


const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root1234',
    port:'3306',
    database: 'guestbook'
});
  
db.connect(function(err) {
    if (err) throw err;
    console.log('Connected!');
});
global.db = db;


app.set('port', process.env.port || port);
app.set('views', __dirname + "/server/views"); // set express to look in this folder to render our view
app.set('view engine', 'ejs'); // configure template engine
app.use(express.static(path.join(__dirname, 'public'))); // configure express to use public folder


// routes for the app
app.get('/', function(req, res) {
    res.render('home.ejs');
});
app.get('/books', getBooksPage);
app.get('/login', function(req, res) {
    res.render('login.ejs');
});

app.get('/signup', user.signup);//call for signup page
app.post('/signup', (req, res) => {
    if (req.method == "POST") {
        const user = {
            username: req.body.username,
            password: req.body.password,
            email: req.body.email
        }
    
    
        db.sql("INSERT INTO users(username, password, email) VALUES ?", user, (err, res) => {
            if (err) throw err;
        });
    
    
        var query = db.query(sql, function (err, result) {
    
            message = "Succesfully! Your account has been created.";
            res.render('signup.ejs', {
                message: message
            });
        });
    } else {
        res.render('login');
    }
    
});//call for signup post 
/* app.get('/books', booksController.list);
app.post('/add', addBook);
app.get('/edit/:id', editBook);
app.get('/delete/:id', deleteBook); */


app.get('*', // * -> catch all routes, all routes have to be required before the *
    (req, res) => res.status(200).send({
        message: 'Welcome to my books list', // welcoming message
    })
);


/* exports the application */
module.exports = app;

app.listen(port, () => {
    console.log(`Server is running on port: ${port}`);
});
