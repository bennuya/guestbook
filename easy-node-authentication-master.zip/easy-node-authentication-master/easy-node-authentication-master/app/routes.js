module.exports = (app, passport) => {

    // show the home page (will also have our login links)
    app.get('/', (req, res) => {
        res.render('index.ejs');
    });

    // profile
    app.get('/profile', isLoggedIn, (req, res) => {
        res.render('profile.ejs', {
            user: req.user
        });
    });

    // logout
    app.get('/logout', (req, res) => {
        req.logout();
        res.redirect('/');
    });

    /** authentication routes */
    // local login
    app.get('/login', (req, res) => {
        res.render('login.ejs', {
            message: req.flash('loginMessage')
        });
    });

    // process login form
    app.post('/login', passport.authenticate('local-login', {
        successRedirect: '/profile',
        failureRedirect: '/login',
        failureFlash: true
    }));

    // signup
    app.get('/signup', (req, res) => {
        res.render('signup.ejs', {
            message: req.flash('signupMessage')
        });
    });


    /* if (req.body['g-recaptcha-response'] === undefined || req.body['g-recaptcha-response'] === '' || req.body['g-recaptcha-response'] === null) {
        return res.json({
            "responseError": "Please select captcha first"
        });
    }
    const secretKey = "6Lcp6aMUAAAAAECmPPjhRbagQ5qzI1voAoE03Z7l";

    const verificationURL = "https://www.google.com/recaptcha/api/siteverify?secret=" + secretKey + "&response=" + req.body['g-recaptcha-response'] + "&remoteip=" + req.connection.remoteAddress;

    request(verificationURL, function (error, response, body) {
        body = JSON.parse(body);

        if (body.success !== undefined && !body.success) {
            return res.json({
                "responseError": "Failed captcha verification",
                failureRedirect: '/signup',
                failureFlash: true
            });
            successRedirect: '/profile'
        }
        res.json({
            "responseSuccess": "Sucess"
        });
    }); */

    // process signup form
    app.post('/signup', function (req, res, request) {
        passport.authenticate('local-signup', {
            successRedirect: '/profile',
            failureRedirect: '/signup',
            failureFlash: true
        });

        if (req.body['g-recaptcha-response'] === undefined || req.body['g-recaptcha-response'] === '' || req.body['g-recaptcha-response'] === null) {
            return res.json({
                "responseError": "Please select captcha first"
            });
        }
        const secretKey = "6Lcp6aMUAAAAAECmPPjhRbagQ5qzI1voAoE03Z7l";

        const verificationURL = "https://www.google.com/recaptcha/api/siteverify?secret=" + secretKey + "&response=" + req.body['g-recaptcha-response'] + "&remoteip=" + req.connection.remoteAddress;

        request(verificationURL, function (error, response, body) {
            body = JSON.parse(body);

            if (body.success !== undefined && !body.success) {
                return res.json({
                    "responseError": "Failed captcha verification",
                    failureRedirect: '/signup',
                    failureFlash: true
                });
                
            }
            res.json({
                "responseSuccess": "Sucess",
            });
        });

        if(grecaptcha.getResponse().length === 0) {
            successRedirect: '/profile'
        }
    });
    /* passport.authenticate('local-signup', {
           successRedirect: '/profile',
           failureRedirect: '/signup',
           failureFlash: true
       } */


    /** google api login */
    // send to google to do the authentication
    app.get('/auth/google', passport.authenticate('google', {
        scope: ['profile', 'email']
    }));

    // the callback after google has authenticated the user
    app.get('/auth/google/callback',
        passport.authenticate('google', {
            successRedirect: '/profile',
            failureRedirect: '/'
        })
    );


    /** twitter api login */
    // send to twitter to do the authentication
    app.get('/auth/twitter', passport.authenticate('twitter', {
        scope: 'email'
    }));

    // handle the callback after twitter has authenticated the user
    app.get('/auth/twitter/callback',
        passport.authenticate('twitter', {
            successRedirect: '/profile',
            failureRedirect: '/'
        })
    );




    /** authorization, already logged in with local */
    /** for connecting another account - facebook, google, twitter */
    // local
    app.get('/connect/local', (req, res) => {
        res.render('connect_local.ejs', {
            message: req.flash('loginMessage')
        });
    });
    app.post('/connect/local', passport.authenticate('local-signup', {
        successRedirect: '/profile',
        failureRedirect: '/connect/local',
        failureFlash: true
    }));


    /** google api login */
    // send to google to do the authentication
    app.get('/connect/google', passport.authorize('google', {
        scope: ['profile', 'email']
    }));

    // the callback after google has authorized the user
    app.get('/connect/google/callback',
        passport.authorize('google', {
            successRedirect: '/profile',
            failureRedirect: '/'
        }));

    /** facebook api login */
    // send to facebook to do the authentication
    app.get('/connect/facebook', passport.authorize('facebook', {
        scope: ['public_profile', 'email']
    }));

    // handle callback after facebook has authorized the user
    app.get('/connect/facebook/callback',
        passport.authorize('facebook', {
            successRedirect: '/profile',
            failureRedirect: '/'
        }));


    /** twitter api login */
    // send to twitter to do the authentication
    app.get('/connect/twitter', passport.authorize('twitter', {
        scope: 'email'
    }));

    // handle callback after twitter has authorized the user
    app.get('/connect/twitter/callback',
        passport.authorize('twitter', {
            successRedirect: '/profile',
            failureRedirect: '/'
        }));




    /** unlink accounts if wanted */
    // local -----------------------------------
    app.get('/unlink/local', isLoggedIn, (req, res) => {
        const user = req.user;
        user.local.email = undefined;
        user.local.password = undefined;
        user.save((err) => {
            res.redirect('/profile');
        });
    });


    /** google api login */
    app.get('/unlink/google', isLoggedIn, (req, res) => {
        const user = req.user;
        user.google.token = undefined;
        user.save((err) => {
            res.redirect('/profile');
        });
    });


    /** facebook api login */
    app.get('/unlink/facebook', isLoggedIn, (req, res) => {
        const user = req.user;
        user.facebook.token = undefined;
        user.save((err) => {
            res.redirect('/profile');
        });
    });


    /** twitter api login */
    app.get('/unlink/twitter', isLoggedIn, (req, res) => {
        const user = req.user;
        user.twitter.token = undefined;
        user.save((err) => {
            res.redirect('/profile');
        });
    });

};

// route middleware to ensure user is logged in
function isLoggedIn(req, res, next) {
    if (req.isAuthenticated())
        return next();
    res.redirect('/');
}