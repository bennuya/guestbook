const LocalStrategy = require('passport-local').Strategy;
const FacebookStrategy = require('passport-facebook').Strategy;
const TwitterStrategy = require('passport-twitter').Strategy;
const GoogleStrategy = require('passport-google-oauth').OAuth2Strategy;

const User = require('../app/models/user');

const configAuth = require('./auth');

module.exports = (passport) => {

    /** passport session setup */
    // used to serialize user for the session
    passport.serializeUser((user, done) => {
        done(null, user.id);
    });

    // used to deserialize user
    passport.deserializeUser((id, done) => {
        User.findById(id, (err, user) => {
            done(err, user);
        });
    });

    /** local login */
    passport.use('local-login', new LocalStrategy({
        // by default, local strategy uses username and password, this will override with email
        usernameField: 'email',
        passwordField: 'password',
        passReqToCallback: true
    }, (req, email, password, done) => {
        if (email) email = email.toLowerCase();

        // async
        process.nextTick(() => {
            User.findOne({
                'local.email': email
            }, (err, user) => {
                if (err) return done(err);

                if (!user) return done(null, false, req.flash('loginMessage', 'No user found.'));

                if (!user.validPassword(password)) return done(null, false, req.flash('loginMessage', 'Oops! Wrong password.'));

                else
                    return done(null, user);
            });
        });

    }));

    /** local signup */
    passport.use('local-signup', new LocalStrategy({
        // by default, local strategy uses username and password, this will override with email
        usernameField: 'email',
        passwordField: 'password',
        passReqToCallback: true
    }, (req, email, password, done) => {
        if (email) email = email.toLowerCase();

        // asynchronous
        process.nextTick(() => {
            // if the user is not already logged in
            if (!req.user) {
                User.findOne({
                    'local.email': email
                }, (err, user) => {
                    if (err) return done(err);

                    // check to see if theres already a user with that email
                    if (user) {
                        return done(null, false, req.flash('signupMessage', 'That email is already taken.'));
                    } else {
                        // create the user
                        const newUser = new User();

                        newUser.local.email = email;
                        newUser.local.password = newUser.generateHash(password);

                        newUser.save((err) => {
                            if (err) return done(err);
                            return done(null, newUser);
                        });
                    }

                });
                // if the user is logged in but has no local account
            } else if (!req.user.local.email) {
                User.findOne({
                    'local.email': email
                }, (err, user) => {
                    if (err) return done(err);

                    if (user) {
                        return done(null, false, req.flash('loginMessage', 'That email is already taken.'));
                    } else {
                        const user = req.user;
                        user.local.email = email;
                        user.local.password = user.generateHash(password);
                        user.save((err) => {
                            if (err) return done(err);
                            return done(null, user);
                        });
                    }
                });
            } else {
                return done(null, req.user);
            }
        });
    }));


    /** twitter login */
    passport.use(new TwitterStrategy({
        consumerKey: configAuth.twitterAuth.consumerKey,
        consumerSecret: configAuth.twitterAuth.consumerSecret,
        callbackURL: configAuth.twitterAuth.callbackURL,
        passReqToCallback: true
    }, (req, token, tokenSecret, profile, done) => {

        // async
        process.nextTick(() => {
            // check if the user is already logged in
            if (!req.user) {
                User.findOne({
                    'twitter.id': profile.id
                }, (err, user) => {
                    if (err) return done(err);

                    if (user) {
                        // if there is a user id already but no token
                        if (!user.twitter.token) {
                            user.twitter.token = token;
                            user.twitter.username = profile.username;
                            user.twitter.displayName = profile.displayName;

                            user.save((err) => {
                                if (err) return done(err);
                                return done(null, user);
                            });
                        }
                        return done(null, user);
                    } else {
                        // if there is no user, create them
                        const newUser = new User();

                        newUser.twitter.id = profile.id;
                        newUser.twitter.token = token;
                        newUser.twitter.username = profile.username;
                        newUser.twitter.displayName = profile.displayName;

                        newUser.save((err) => {
                            if (err) return done(err);
                            return done(null, newUser);
                        });
                    }
                });
            } else {
                // user already exists and is logged in
                const user = req.user; // pull the user out of the session

                user.twitter.id = profile.id;
                user.twitter.token = token;
                user.twitter.username = profile.username;
                user.twitter.displayName = profile.displayName;

                user.save((err) => {
                    if (err) return done(err);
                    return done(null, user);
                });
            }

        });

    }));

    /** google login */
    passport.use(new GoogleStrategy({
        clientID: configAuth.googleAuth.clientID,
        clientSecret: configAuth.googleAuth.clientSecret,
        callbackURL: configAuth.googleAuth.callbackURL,
        passReqToCallback: true
    }, (req, token, refreshToken, profile, done) => {

        // async
        process.nextTick(() => {
            // check if the user is already logged in
            if (!req.user) {
                User.findOne({
                    'google.id': profile.id
                }, (err, user) => {
                    if (err) return done(err);

                    if (user) {
                        // if there is a user id already but no token
                        if (!user.google.token) {
                            user.google.token = token;
                            user.google.name = profile.displayName;
                            user.google.email = (profile.emails[0].value || '').toLowerCase(); // pull the first email

                            user.save((err) => {
                                if (err) return done(err);
                                return done(null, user);
                            });
                        }
                        return done(null, user);
                    } else {
                        const newUser = new User();

                        newUser.google.id = profile.id;
                        newUser.google.token = token;
                        newUser.google.name = profile.displayName;
                        newUser.google.email = (profile.emails[0].value || '').toLowerCase(); // pull the first email

                        newUser.save((err) => {
                            if (err) return done(err);
                            return done(null, newUser);
                        });
                    }
                });
            } else {
                // user already exists and is logged in
                const user = req.user; // pull the user out of the session

                user.google.id = profile.id;
                user.google.token = token;
                user.google.name = profile.displayName;
                user.google.email = (profile.emails[0].value || '').toLowerCase(); // pull the first email

                user.save((err) => {
                    if (err) return done(err);
                    return done(null, user);
                });
            }
        });
    }));
};