module.exports = {
    /* 'facebookAuth': {
        'clientID': 'your-secret-clientID-here',
        'clientSecret': 'your-client-secret-here',
        'callbackURL': 'http://localhost:8080/auth/facebook/callback',
        'profileURL': 'https://graph.facebook.com/v2.5/me?fields=first_name,last_name,email',
        'profileFields': ['id', 'email', 'name']
    }, */

    'twitterAuth': {
        'consumerKey': 'your-consumer-key-here',
        'consumerSecret': 'your-client-secret-here',
        'callbackURL': 'http://localhost:8080/auth/twitter/callback'
    },

    'googleAuth': {
        'clientID': '509815628411-jpscgr57mnha0b6h51bt3kmvn3t52qgl.apps.googleusercontent.com',
        'clientSecret': 'r-GU1B6LBvJyRvNBFgpdJcGg',
        'callbackURL': 'http://localhost:8080/auth/google/callback'
    }
};